<?php

namespace Resend;

class Broadcast extends Resource
{
    //
}
