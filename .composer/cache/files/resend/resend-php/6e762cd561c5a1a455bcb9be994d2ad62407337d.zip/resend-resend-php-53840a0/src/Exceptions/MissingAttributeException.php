<?php

namespace Resend\Exceptions;

use OutOfBoundsException;

class MissingAttributeException extends OutOfBoundsException
{
    //
}
