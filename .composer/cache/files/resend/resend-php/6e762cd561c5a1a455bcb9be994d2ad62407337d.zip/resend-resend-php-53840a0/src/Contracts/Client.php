<?php

namespace Resend\Contracts;

interface Client
{
    //
}
