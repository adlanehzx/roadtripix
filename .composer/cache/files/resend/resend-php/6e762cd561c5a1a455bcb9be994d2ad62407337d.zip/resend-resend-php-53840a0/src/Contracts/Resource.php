<?php

namespace Resend\Contracts;

use ArrayAccess;
use JsonSerializable;

interface Resource extends ArrayAccess, JsonSerializable
{
    //
}
