<?php

namespace Resend\Exceptions;

use Exception;

class WebhookSignatureVerificationException extends Exception
{
}
