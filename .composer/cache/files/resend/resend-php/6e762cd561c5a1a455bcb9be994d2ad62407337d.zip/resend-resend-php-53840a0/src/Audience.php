<?php

namespace Resend;

/**
 * @property string $id The unique identifier for the Audience.
 * @property string $name The name of the Audience.
 * @property string $created_at Time at which the Audience was created.
 */
class Audience extends Resource
{
    //
}
